package com.example.quidditchscoretracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
int scoreA = 0;
int scoreB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForTeamA(scoreA);
        displayForTeamB(scoreB);
    }

    public void add10TeamA(View view) {
        scoreA = scoreA + 10;
        displayForTeamA(scoreA);

    }

    public void add150TeamA(View view) {
        scoreA = scoreA + 150;
        displayForTeamA(scoreA);

    }
    public void add10TeamB(View view) {
        scoreB = scoreB + 10;
        displayForTeamB(scoreB);

    }

    public void add150TeamB(View view) {
        scoreB = scoreB + 150;
        displayForTeamB(scoreB);

    }

    public void resetScores(View view) {
        scoreA = 0;
        scoreB = 0;
        displayForTeamA(scoreA);
        displayForTeamB(scoreB);
    }

    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int scoreA) {
        TextView scoreView = findViewById(R.id.scoreTeamA);
        scoreView.setText(String.valueOf(scoreA));
    }

    /**
     * Displays the given score for Team B.
     */
    public void displayForTeamB(int scoreB) {
        TextView scoreView = findViewById(R.id.scoreTeamB);
        scoreView.setText(String.valueOf(scoreB));
    }



}
